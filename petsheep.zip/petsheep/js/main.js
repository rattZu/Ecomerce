(function ($) {
    "use strict";

    // Adiciona ou remove a classe 'sticky-top' na navbar ao rolar a página
    $(window).scroll(function () {
        if ($(this).scrollTop() > 40) {
            // Adiciona a classe 'sticky-top' para fixar a navbar no topo
            $('.navbar').addClass('sticky-top');
        } else {
            // Remove a classe 'sticky-top' quando o scroll é menor que 40px
            $('.navbar').removeClass('sticky-top');
        }
    });

    // Executa o código quando o DOM estiver completamente carregado
    $(document).ready(function () {
        // Função para alternar o comportamento do dropdown da navbar com base no tamanho da janela
        function toggleNavbarMethod() {
            if ($(window).width() > 992) {
                // Para telas maiores que 992px, ativa o dropdown no hover
                $('.navbar .dropdown').on('mouseover', function () {
                    $('.dropdown-toggle', this).trigger('click');
                }).on('mouseout', function () {
                    $('.dropdown-toggle', this).trigger('click').blur();
                });
            } else {
                // Para telas menores ou iguais a 992px, remove os eventos de hover
                $('.navbar .dropdown').off('mouseover').off('mouseout');
            }
        }
        // Chama a função para configurar o comportamento inicial
        toggleNavbarMethod();
        // Reexecuta a função ao redimensionar a janela
        $(window).resize(toggleNavbarMethod);
    });

    // Configura o comportamento do modal de vídeo
    $(document).ready(function () {
        var $videoSrc; // Variável para armazenar a URL do vídeo
        $('.btn-play').click(function () {
            // Obtém a URL do vídeo do atributo 'data-src' do botão clicado
            $videoSrc = $(this).data("src");
        });
        console.log($videoSrc);

        // Quando o modal é exibido, adiciona a URL do vídeo com autoplay
        $('#videoModal').on('shown.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0");
        });

        // Quando o modal é fechado, remove o autoplay do vídeo
        $('#videoModal').on('hide.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc);
        });
    });

    // Mostra ou oculta o botão "voltar ao topo" com base no scroll
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            // Mostra o botão com animação
            $('.back-to-top').fadeIn('slow');
        } else {
            // Oculta o botão com animação
            $('.back-to-top').fadeOut('slow');
        }
    });

    // Anima o scroll para o topo ao clicar no botão "voltar ao topo"
    $('.back-to-top').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 1500, 'easeInOutExpo');
        return false; // Previne o comportamento padrão do clique
    });

    // Configura o carrossel de produtos usando o Owl Carousel
    $(".product-carousel").owlCarousel({
        autoplay: true, // Ativa o autoplay
        smartSpeed: 1000, // Velocidade da transição
        margin: 45, // Margem entre os itens
        dots: false, // Oculta os pontos de navegação
        loop: true, // Ativa o loop infinito
        nav: true, // Mostra os botões de navegação
        navText: [
            '<i class="bi bi-arrow-left"></i>', // Ícone para o botão "anterior"
            '<i class="bi bi-arrow-right"></i>' // Ícone para o botão "próximo"
        ],
        responsive: {
            0: { items: 1 }, // 1 item para telas pequenas
            768: { items: 2 }, // 2 itens para telas médias
            992: { items: 3 }, // 3 itens para telas grandes
            1200: { items: 4 } // 4 itens para telas muito grandes
        }
    });

    // Configura o carrossel da equipe usando o Owl Carousel
    $(".team-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        margin: 45,
        dots: false,
        loop: true,
        nav: true,
        navText: [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
        responsive: {
            0: { items: 1 },
            768: { items: 2 },
            992: { items: 3 },
            1200: { items: 4 }
        }
    });

    // Configura o carrossel de depoimentos usando o Owl Carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        items: 1, // Mostra apenas 1 item por vez
        dots: false,
        loop: true,
        nav: true,
        navText: [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
    });

})(jQuery); // Passa o jQuery como argumento para evitar conflitos com outras bibliotecas