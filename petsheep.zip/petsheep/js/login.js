// Obtém o elemento com o ID 'container' do DOM
let container = document.getElementById('container')

// Função para alternar entre as classes 'sign-in' e 'sign-up' no elemento 'container'
toggle = () => {
    // Adiciona ou remove a classe 'sign-in'
    container.classList.toggle('sign-in')
    // Adiciona ou remove a classe 'sign-up'
    container.classList.toggle('sign-up')
}

// Após 200ms, adiciona a classe 'sign-in' ao elemento 'container'
// Isso pode ser usado para iniciar a animação ou o estado inicial da página
setTimeout(() => {
    container.classList.add('sign-in')
}, 200)

// Obtém o botão de alternância de tema pelo ID 'theme-toggle'
const themeToggleBtn = document.getElementById('theme-toggle');

// Obtém o elemento <body> do documento
const body = document.body;

// Nota: O código acima define variáveis e funções, mas o botão de alternância de tema ('themeToggleBtn') 
// ainda não possui um evento associado. Você pode adicionar um evento de clique para alternar temas, 
// caso necessário.