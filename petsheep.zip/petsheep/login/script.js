let container = document.getElementById('container')

toggle = () => {
	container.classList.toggle('sign-in')
	container.classList.toggle('sign-up')
}

setTimeout(() => {
	container.classList.add('sign-in')
}, 200)

// Seleciona o botão de alternância
const themeToggleBtn = document.getElementById('theme-toggle');
const body = document.body;

// Verifica se o tema escuro está ativado no armazenamento local e aplica automaticamente
if (localStorage.getItem('theme') === 'dark') {
    body.classList.add('dark-mode');
    themeToggleBtn.textContent = 'Modo Claro'; // Muda o texto do botão para "Modo Claro"
}

// Adiciona um ouvinte de evento para alternar o tema ao clicar no botão
themeToggleBtn.addEventListener('click', () => {
    // Alterna a classe 'dark-mode' no body
    body.classList.toggle('dark-mode');

    // Verifica se o corpo tem a classe 'dark-mode' para definir o texto do botão
    if (body.classList.contains('dark-mode')) {
        themeToggleBtn.textContent = 'Modo Claro'; // Se estiver no modo escuro, o texto do botão muda para "Modo Claro"
        // Armazena a preferência do tema no localStorage para persistir a escolha
        localStorage.setItem('theme', 'dark');
    } else {
        themeToggleBtn.textContent = 'Modo Escuro'; // Se estiver no modo claro, o texto do botão muda para "Modo Escuro"
        // Remove a preferência do tema do localStorage
        localStorage.removeItem('theme');
    }
});
